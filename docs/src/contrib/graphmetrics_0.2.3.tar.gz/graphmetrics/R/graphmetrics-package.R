#' @importFrom methods is
#' @importFrom stats pchisq rbinom rnorm rpois runif
#' @importFrom utils combn
#' @importFrom Matrix norm
#' @importFrom iGraphMatch gm graphMatch
#' @importFrom Rcpp sourceCpp
#' @importFrom ROI L_constraint OP Q_objective ROI_solve
NULL

#' @useDynLib graphmetrics, .registration = TRUE
NULL